import statistics

def mean(data):
    
    return statistics.mean(data)

def mode(data):

    return statistics.mode(data)

def median(data):

    return statistics.median(data)