

#__init__ file for package my statistics

from .statisticscode import mode, median, mean