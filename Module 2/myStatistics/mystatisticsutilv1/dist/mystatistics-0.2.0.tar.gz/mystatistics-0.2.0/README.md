# My Statistics Module

A module that can calculate mean, median, and mode of a dataset

## Usage

python
import mystatistics

#Calculates mean
mystatistics.mean(dataset)

#Calculates median
mystatistics.median(dataset)

#Calculates mode
mystatistics.mode(dataset)


## Description

This package can calculate the mean median and mode given a list of numbers. It uses the the statistics module to accomplish this.
